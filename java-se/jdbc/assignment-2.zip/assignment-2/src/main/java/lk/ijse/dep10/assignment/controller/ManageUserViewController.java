package lk.ijse.dep10.assignment.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class ManageUserViewController {

    public Button btnDeleteUser;
    public Button btnNewUser;
    public Button btnSaveUser;
    public TableView<?> tblUsers;
    public TextField txtFullName;
    public TextField txtPassword;
    public TextField txtUsername;

    
    public void btnDeleteUserOnAction(ActionEvent event) {

    }

    
    public void btnNewUserOnAction(ActionEvent event) {

    }

    
    public void btnSaveUserOnAction(ActionEvent event) {

    }

    
    public void tblUsersOnKeyReleased(KeyEvent event) {

    }

}
