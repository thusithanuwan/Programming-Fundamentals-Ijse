package lk.ijse.dep10.assignment;

public class AppInitializerWrapper {

    public static void main(String[] args) {
        AppInitializer.main(args);
    }
}
