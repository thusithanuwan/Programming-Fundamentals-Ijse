# JDBC Assignment 2

A simple assignment to evaluate your skills and knowledge in JDBC and SQL

### License
Copyright 2023 DEP. All Rights Reserved.
